
import tkinter as tk
from tkinter import ttk, messagebox

class Account:
    def __init__(self, account_id, balance=0):
        self.account_id = account_id
        self.balance = balance

    def __str__(self):
        return f"Account ID: {self.account_id}, Balance: {self.balance}"

class Transaction:
    def __init__(self, transaction_id, transaction_type, amount):
        self.transaction_id = transaction_id
        self.transaction_type = transaction_type
        self.amount = amount

    def __str__(self):
        return f"Transaction ID: {self.transaction_id}, Type: {self.transaction_type}, Amount: {self.amount}"

class BankingSystem:
    def __init__(self):
        self.accounts = {}
        self.transaction_log = {}

    def create_account(self, account_id):
        if account_id in self.accounts:
            raise ValueError("Account already exists.")
        self.accounts[account_id] = Account(account_id)
        return f"Account created: {self.accounts[account_id]}"

    def deposit(self, account_id, transaction_id, amount):
        if transaction_id in self.transaction_log:
            raise ValueError("Duplicate transaction.")
        if account_id not in self.accounts:
            raise ValueError("Account does not exist.")
        if amount <= 0:
            raise ValueError("Deposit amount must be positive.")
        self.accounts[account_id].balance += amount
        self.transaction_log[transaction_id] = Transaction(transaction_id, "Deposit", amount)
        return f"Deposit successful: {self.transaction_log[transaction_id]}, New balance: {self.accounts[account_id]}"

    def withdraw(self, account_id, transaction_id, amount):
        if transaction_id in self.transaction_log:
            raise ValueError("Duplicate transaction.")
        if account_id not in self.accounts:
            raise ValueError("Account does not exist.")
        if amount <= 0 or amount > self.accounts[account_id].balance:
            raise ValueError("Invalid withdrawal amount.")
        self.accounts[account_id].balance -= amount
        self.transaction_log[transaction_id] = Transaction(transaction_id, "Withdrawal", amount)
        return f"Withdrawal successful: {self.transaction_log[transaction_id]}, New balance: {self.accounts[account_id]}"

class BankingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Banking System")
        self.system = BankingSystem()

        style = ttk.Style()
        style.configure("TButton", font=("Helvetica", 12))
        style.configure("TLabel", font=("Helvetica", 12))
        style.configure("TEntry", font=("Helvetica", 12))

        self.account_label = ttk.Label(root, text="Account ID:")
        self.account_label.pack(pady=5)
        self.account_entry = ttk.Entry(root)
        self.account_entry.pack(pady=5)

        self.transaction_label = ttk.Label(root, text="Transaction ID:")
        self.transaction_label.pack(pady=5)
        self.transaction_entry = ttk.Entry(root)
        self.transaction_entry.pack(pady=5)

        self.amount_label = ttk.Label(root, text="Amount:")
        self.amount_label.pack(pady=5)
        self.amount_entry = ttk.Entry(root)
        self.amount_entry.pack(pady=5)

        self.create_account_button = ttk.Button(root, text="Create Account", command=self.create_account)
        self.create_account_button.pack(pady=5)

        self.deposit_button = ttk.Button(root, text="Deposit", command=self.deposit)
        self.deposit_button.pack(pady=5)

        self.withdraw_button = ttk.Button(root, text="Withdraw", command=self.withdraw)
        self.withdraw_button.pack(pady=5)

        self.view_balance_button = ttk.Button(root, text="View Balance", command=self.view_balance)
        self.view_balance_button.pack(pady=5)

    def create_account(self):
        account_id = self.account_entry.get()
        try:
            result = self.system.create_account(account_id)
            messagebox.showinfo("Success", result)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def deposit(self):
        account_id = self.account_entry.get()
        transaction_id = self.transaction_entry.get()
        amount = self.amount_entry.get()
        try:
            result = self.system.deposit(account_id, transaction_id, float(amount))
            messagebox.showinfo("Success", result)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def withdraw(self):
        account_id = self.account_entry.get()
        transaction_id = self.transaction_entry.get()
        amount = self.amount_entry.get()
        try:
            result = self.system.withdraw(account_id, transaction_id, float(amount))
            messagebox.showinfo("Success", result)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def view_balance(self):
        account_id = self.account_entry.get()
        if account_id in self.system.accounts:
            balance = self.system.accounts[account_id].balance
            messagebox.showinfo("Balance", f"Balance: {balance}")
        else:
            messagebox.showerror("Error", "Account does not exist.")

if __name__ == "__main__":
    root = tk.Tk()
    app = BankingApp(root)
    root.mainloop()
