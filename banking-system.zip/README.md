
# Banking System

A simple banking system application built with Python and tkinter, including an Alloy model for transaction validation.

## Features
- Create accounts
- Deposit and withdraw money
- View account balance
- Validate transactions with Alloy

## Installation
1. Install Python 3.x.
2. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/banking-system.git
   ```
3. Run the application:
   ```bash
   python main.py
   ```

## Alloy Model
The Alloy model is located in the `alloy/` directory. Use the Alloy Analyzer to validate transaction rules.

## Contribution
Feel free to fork the repository and submit pull requests!
